import boto3
import os
import json
from uuid import uuid4
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['TABLE_NAME'])

def lambda_handler(event, context):
    body = json.loads(event['body'])
    log_entry = {
        "logId": str(uuid4()),
        "timestamp": int(datetime.utcnow().timestamp()),
        "message": body['message'],
        "level": body.get('level', 'INFO')
    }
    table.put_item(Item=log_entry)
    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Log saved", "logId": log_entry['logId']})
    }
