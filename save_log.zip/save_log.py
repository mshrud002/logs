#importing lambda libraries
import boto3
import os
import json
from uuid import uuid4
from datetime import datetime

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['TABLE_NAME'])


# Lambda handler function
def lambda_handler(event, context):
    body = json.loads(event['body'])
    log_entry = {
        "logId": str(uuid4()), #Uniques identifier
        "DateTime": int(datetime.utcnow().timestamp()),
        "Message": body['message'],
        "Severity": body.get('severity', 'INFO', 'warning', 'error')
    }
    # Save the log entries to DynamoDB
    table.put_item(Item=log_entry)
    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Log saved", "logId": log_entry['logId']})
    }
