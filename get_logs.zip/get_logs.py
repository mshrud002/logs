#Import python libraries
import boto3
import os
import json

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['TABLE_NAME'])

def lambda_handler(event, context):
    response = table.scan()
    items = response.get('Items', [])
    # Sort logs by timestamp in descending order and return the top 100
    sorted_logs = sorted(items, key=lambda x: x['timestamp'], reverse=True)[:100]
    return {
        "statusCode": 200,
        "body": json.dumps(sorted_logs)
    }
